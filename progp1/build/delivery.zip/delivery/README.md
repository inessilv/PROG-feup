
# Trabalho de programação

## Grupo
    Grupo constituído por: 
      up202008076     -> Inês Sousa da Silva
      up202004374      -> Tiago Campos Lourenço

## Tarefas realizadas

Foram concluídas todas as tarefas. 


